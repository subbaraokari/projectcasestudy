package org.greatlearning;

import java.util.Comparator;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		TreeSet<Integer> ts=new TreeSet<>(new NumberComparator());
		ts.add(10);
		ts.add(5);
		ts.add(30);
		ts.add(200);
		System.out.println(ts);
		
	}
}
class NumberComparator implements Comparator<Integer>
{
	@Override
	public int compare(Integer i1, Integer i2) {
		
		return -i1.compareTo(i2);
	}
	
}
